#!/usr/bin/env bash
set -euo pipefail

DEFAULT_KERNEL_VERSION="6.12.47+rpt-rpi-v8"
TARGET_KERNEL="${1:-${DEFAULT_KERNEL_VERSION}}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULE_SRC="${SCRIPT_DIR}/lib/modules/${TARGET_KERNEL}/extra/simtemp.ko"
DTBO_SRC="${SCRIPT_DIR}/boot/overlays/simtemp.dtbo"
STUB_SRC="${SCRIPT_DIR}/opt/simtemp/simtemp_pdev_stub.ko"

MODULE_DEST="/lib/modules/${TARGET_KERNEL}/extra"
DTBO_DEST="/boot/overlays"
STUB_DEST="/usr/lib/simtemp"

if [[ "$EUID" -ne 0 ]]; then
	echo "Please run this script with sudo (root privileges required)." >&2
	exit 1
fi

install -d "${MODULE_DEST}" "${DTBO_DEST}" "${STUB_DEST}"
install -m 644 "${MODULE_SRC}" "${MODULE_DEST}/simtemp.ko"
install -m 644 "${DTBO_SRC}" "${DTBO_DEST}/simtemp.dtbo"

if [[ -f "${STUB_SRC}" ]]; then
	install -m 644 "${STUB_SRC}" "${STUB_DEST}/simtemp_pdev_stub.ko"
fi

APP_SRC="${SCRIPT_DIR}/opt/simtemp-ui"
APP_DEST="/opt/simtemp-ui"
LAUNCHER_PATH="/usr/local/bin/API_SimTemp"

if [[ ! -d "${APP_SRC}" ]]; then
	echo "Application sources missing inside the package." >&2
	exit 1
fi

rm -rf "${APP_DEST}"
install -d "${APP_DEST}"
cp -r "${APP_SRC}/." "${APP_DEST}/"

PYTHON_BIN="$(command -v python3 || true)"
if [[ -z "${PYTHON_BIN}" ]]; then
	echo "python3 not found. Please install python3 before running this installer." >&2
	exit 1
fi

if ! "${PYTHON_BIN}" -m venv "${APP_DEST}/.venv"; then
	echo "Failed to create Python virtual environment. Install python3-venv and retry." >&2
	exit 1
fi

"${APP_DEST}/.venv/bin/pip" install --upgrade pip
"${APP_DEST}/.venv/bin/pip" install -r "${APP_DEST}/requirements.txt"

PERM_SCRIPT="${SCRIPT_DIR}/scripts/setup_simtemp_permissions.sh"
PERM_GROUP="${SIMTEMP_GROUP:-plugdev}"
PERM_USER="${SIMTEMP_USER:-${SUDO_USER:-}}"
if [[ -x "${PERM_SCRIPT}" ]]; then
	SIMTEMP_PROJECT_ROOT="${APP_DEST}" SIMTEMP_GROUP="${PERM_GROUP}" SIMTEMP_USER="${PERM_USER}" bash "${PERM_SCRIPT}"
else
	echo "WARNING: Permission setup script missing; adjust sysfs permissions manually." >&2
fi

cat > "${LAUNCHER_PATH}" <<'LAUNCHER'
#!/usr/bin/env bash
APP_HOME="/opt/simtemp-ui"
VENV_PY="${APP_HOME}/.venv/bin/python"
if [[ ! -x "${VENV_PY}" ]]; then
	echo "simtemp UI virtualenv missing. Re-run install.sh." >&2
	exit 1
fi
exec "${VENV_PY}" "${APP_HOME}/main.py" "$@"
LAUNCHER
chmod +x "${LAUNCHER_PATH}"

BOOT_CONFIG=""
if [[ -f /boot/firmware/config.txt ]]; then
	BOOT_CONFIG=/boot/firmware/config.txt
elif [[ -f /boot/config.txt ]]; then
	BOOT_CONFIG=/boot/config.txt
fi

if [[ -n "${BOOT_CONFIG}" ]]; then
	if ! grep -Eq '^[[:space:]]*dtoverlay=simtemp([[:space:]]|$)' "${BOOT_CONFIG}"; then
		echo "dtoverlay=simtemp" >> "${BOOT_CONFIG}"
		echo "Added dtoverlay=simtemp to ${BOOT_CONFIG}."
	else
		echo "dtoverlay=simtemp already present in ${BOOT_CONFIG}."
	fi
else
	echo "WARNING: Could not find /boot/config.txt or /boot/firmware/config.txt to persist overlay." >&2
fi

depmod "${TARGET_KERNEL}"

cat <<'MSG'
Installation complete.

To load the overlay (if not already active):
  sudo dtoverlay simtemp

To insert the kernel module:
  sudo insmod /lib/modules/$(uname -r)/extra/simtemp.ko

If you require the ACPI stub (mostly x86 only), it was installed at /usr/lib/simtemp/simtemp_pdev_stub.ko.
To launch the GUI:
  API_SimTemp
To uninstall later, run sudo ./uninstall.sh [kernel-version]
MSG
