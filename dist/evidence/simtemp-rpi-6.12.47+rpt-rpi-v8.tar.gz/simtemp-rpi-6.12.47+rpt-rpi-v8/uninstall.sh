#!/usr/bin/env bash
set -euo pipefail

DEFAULT_KERNEL_VERSION="6.12.47+rpt-rpi-v8"
TARGET_KERNEL="${1:-${DEFAULT_KERNEL_VERSION}}"

MODULE_DEST="/lib/modules/${TARGET_KERNEL}/extra/simtemp.ko"
DTBO_DEST="/boot/overlays/simtemp.dtbo"
STUB_PATH="/usr/lib/simtemp/simtemp_pdev_stub.ko"
APP_DEST="/opt/simtemp-ui"
LAUNCHER_PATH="/usr/local/bin/API_SimTemp"

if [[ "$EUID" -ne 0 ]]; then
	echo "Please run this script with sudo (root privileges required)." >&2
	exit 1
fi

modprobe -r simtemp 2>/dev/null || true
modprobe -r simtemp_pdev_stub 2>/dev/null || true

rm -f "${MODULE_DEST}"
rm -f "${DTBO_DEST}"
rm -f "${STUB_PATH}"
rm -f "${LAUNCHER_PATH}"
rm -rf "${APP_DEST}"

rmdir --ignore-fail-on-non-empty /usr/lib/simtemp 2>/dev/null || true
rmdir --ignore-fail-on-non-empty "/lib/modules/${TARGET_KERNEL}/extra" 2>/dev/null || true

UDEV_RULE="/etc/udev/rules.d/99-nxp-simtemp.rules"
if [[ -f "${UDEV_RULE}" ]]; then
	rm -f "${UDEV_RULE}"
	udevadm control --reload || true
	udevadm trigger --subsystem-match=misc --attr-match=name=nxp_simtemp || true
fi

BOOT_CONFIG=""
if [[ -f /boot/firmware/config.txt ]]; then
	BOOT_CONFIG=/boot/firmware/config.txt
elif [[ -f /boot/config.txt ]]; then
	BOOT_CONFIG=/boot/config.txt
fi

if [[ -n "${BOOT_CONFIG}" ]]; then
	sed -i '/^[[:space:]]*dtoverlay=simtemp$/d' "${BOOT_CONFIG}"
fi

depmod "${TARGET_KERNEL}"

echo "simtemp files removed for kernel ${TARGET_KERNEL}."
