simtemp kernel module package for Raspberry Pi

Contents:
  - lib/modules/6.12.47+rpt-rpi-v8/extra/simtemp.ko
  - boot/overlays/simtemp.dtbo
  - opt/simtemp-ui/* (Python GUI sources and requirements)
  - opt/simtemp/simtemp_pdev_stub.ko (optional stub for non-Device Tree systems)
  - scripts/setup_simtemp_permissions.sh (applied during install)
  - install.sh helper script
  - uninstall.sh helper script

Usage:
  1. Copy simtemp-rpi-6.12.47+rpt-rpi-v8.tar.gz to the Raspberry Pi.
  2. On the Raspberry Pi, extract it: tar -xzf simtemp-rpi-6.12.47+rpt-rpi-v8.tar.gz
  3. Run sudo ./simtemp-rpi-6.12.47+rpt-rpi-v8/install.sh
     (you may pass a kernel version as the first argument if different from 6.12.47+rpt-rpi-v8)
  4. The script ensures dtoverlay=simtemp is present in the Raspberry Pi boot config so it loads on boot.
  5. Launch the GUI afterwards with API_SimTemp.
  6. To remove the installation, run sudo ./simtemp-rpi-6.12.47+rpt-rpi-v8/uninstall.sh [kernel-version].
     (You may need to log out/in once so new group membership takes effect.)
